Stock & Billing Android wrapper project

This is an Android Studio project source package, not a compiled APK.
It packages the existing Stock_Billing_Final.html in an Android WebView,
enables JavaScript/localStorage for offline use, and routes backup export to
Android's Save dialog. Restore uses Android's file picker.

Build an APK:
1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Extract this ZIP.
3. Open the StockBillingAndroid folder in Android Studio and allow Gradle sync.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location (usually app/build/outputs/apk/debug/app-debug.apk).

Important data note:
The app's localStorage is separate from the browser's localStorage. Before switching,
open your existing Stock & Billing HTML in the same browser where your records live,
open Backup, and download a JSON backup. Install the APK, open Backup & Restore,
and restore that JSON file. Verify item balances and orders before using it for live work.

No stock records are embedded in this project. Keep the backup in a safe location.
